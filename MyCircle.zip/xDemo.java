//This program demonstrates the Circle class's setX method

public class xDemo 
{
	public static void main(String[]args)
	{
		//Create a Circle object and assign its address to the circle variable
		MyCircle circle = new MyCircle();
	
		//Indicate what we are doing
		System.out.println("Sending the value 10.0 " + "to the setX method.");
	
		//Call the box object's setX method.
		circle.setX(10.0);
	
		//Indicate we are done
		System.out.println("Done.");	
	}
}
