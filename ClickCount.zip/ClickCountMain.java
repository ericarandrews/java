import javax.swing.*;

public class ClickCountMain {

	public static void main(String[] args) {
		JFrame frame = new ClickCountFrame();

		frame.setVisible(true);
	}
}